export const SOURCE = {
  CACHE: 'CACHE',
  ACTUAL: 'ACTUAL',
};
