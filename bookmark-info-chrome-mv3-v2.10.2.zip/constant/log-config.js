export const LOG_CONFIG = {
  SHOW_LOG_CACHE: false,
  SHOW_LOG_EVENT_OUT: false,
  SHOW_LOG_EVENT_IN: false,
  SHOW_LOG_IGNORE: false,
  SHOW_LOG_OPTIMIZATION: false,
  SHOW_LOG_QUEUE: false,
  SHOW_LOG: false,
  SHOW_DEBUG: false,
  SHOW_SETTINGS: false,
}